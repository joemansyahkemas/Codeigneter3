<?php
class Home_model extends CI_Model{
    function get_data_produk(){
        //jika result data ditampilkan berbentuk objek
        //jika result_array data ditampilkan berbentuk array
        // $this->db->select('ProdukID,NamaProduk');
        $this->db->from('produk');
        $result = $this->db->get()->result();
        return $result;
    }
    function simpan_produk($Namaproduk,$Hargaproduk,$Keterangan){
        // sebelah kiri didalam petik ini nama field didalam table database
        // sebelah kanan nama variable yang dikirim dari form dan controller
        $data = array(
            'NamaProduk' => $Namaproduk,
            'HargaProduk' => $Hargaproduk,
            'KeteranganProduk' => $Keterangan
        );
        $query = $this->db->insert('produk',$data);
        return $query;
    }
    function update_produk($Namaproduk,$Hargaproduk,$Keterangan,$ProdukID){
        $data = array(
            'NamaProduk' => $Namaproduk,
            'HargaProduk' => $Hargaproduk,
            'KeteranganProduk' => $Keterangan
        );
        $this->db->where('ProdukID', $ProdukID);
        $query = $this->db->update('produk',$data);
        return $query;
    }
    function hapus_produk($IdProduk){
        //sebelah kiri nama field yang ada dalam table databse
        $this->db->where('ProdukID', $IdProduk);
        $query = $this->db->delete('produk');
        return $query;
    }
    function get_produk_id($IdProduk){
        // kalau data yang ditampilkan hanya satu gunakan row
        // lebih dari satu gunakan result
        $this->db->where('ProdukID',$IdProduk);
        $this->db->from('produk');
        $result = $this->db->get()->row_array();
        return $result;
    }
}