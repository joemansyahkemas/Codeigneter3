<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tes extends CI_Controller {

	public function coba()
	{
		echo "<h1>Hello Word</h1>";
	}
	public function index()
	{
		echo "<h1>Hello </h1>";
	}
}
