<?php
class Home extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('home_model');
    }
    function index(){
        $data['tema'] = 'Halaman Utama';
        $this->load->view('template/Header',$data);
        $this->load->view('pages/Halaman_utama');
        $this->load->view('template/Footer');
    }
    function profil(){
        $this->load->view('template/Header');
        $this->load->view('pages/Halaman_profil');
        $this->load->view('template/Footer');
    }
    function kalkulator(){
        $this->load->view('template/Header');
        $this->load->view('pages/Kalkulator');
        $this->load->view('template/Footer');
    }
    function data_produk(){
        $data['tema'] = 'Halaman Data Produk';
        $data['produk'] = $this->home_model->get_data_produk();
        // echo "<pre>";
        // var_dump($data);
        // echo "</pre>";
        $this->load->view('template/Header',$data);
        $this->load->view('pages/Data_produk');
        $this->load->view('template/Footer');
    }
    function add_produk(){
        $data['tema'] = 'Halaman Tambah Data Produk';
        $this->load->view('template/Header',$data);
        $this->load->view('pages/Add_produk');
        $this->load->view('template/Footer');
    }
    function edit_produk($ProdukID){
        $data['tema'] = 'Halaman Edit Data Produk';
        $data['produk'] = $this->home_model->get_produk_id($ProdukID);
        $this->load->view('template/Header',$data);
        $this->load->view('pages/Edit_produk');
        $this->load->view('template/Footer');
    }
}