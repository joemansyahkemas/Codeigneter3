<?php
class Homeproses extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('home_model');
    }
    function proseshitung(){
        $angka1 = $this->input->post('angka1');
        $angka2 = $this->input->post('angka2');
        $operator = $this->input->post('operator');
        if($operator == '+'){
            $hasil = $angka1 + $angka2;
            echo $angka1.'+'.$angka2.'='.$hasil;
        }elseif($operator == '-'){
            $hasil = $angka2 - $angka2;
            echo $angka1.'-'.$angka2.'='.$hasil;
        }elseif($operator == '/'){ 
            $hasil = $angka2 / $angka2;
            echo $angka1.'/'.$angka2.'='.$hasil;
        }elseif($operator == '*'){
            $hasil = $angka2 * $angka2;
            echo $angka1.'*'.$angka2.'='.$hasil;
        }else{
            echo "Operator belum didukung oleh sistem";
        }
    }
    function simpandata(){
        // sebelah kiri itu variable baru
        // sebelah kanan variable dari form input
        $Namaproduk = $this->input->post('NamaProduk');
        $Hargaproduk = $this->input->post('HargaProduk');
        $Keterangan =  $this->input->post('Keterangan');
        $query = $this->home_model->simpan_produk($Namaproduk,$Hargaproduk,$Keterangan);
        if($query){
            // FLASS untuk notifikasi / pemberitahuan
            $this->session->set_flashdata('notifikasi','<div class="alert alert-primary" role="alert">Data berhasil disimpan</div>');
        }else{
            $this->session->set_flashdata('notifikasi','<div class="alert alert-danger" role="alert">Data gagal disimpan</div>');
        }
        redirect('home/data_produk');
    }
    function updatedata(){
        $Namaproduk     = $this->input->post('NamaProduk');
        $Hargaproduk    = $this->input->post('HargaProduk');
        $Keterangan     = $this->input->post('Keterangan');
        $ProdukID       = $this->input->post('ProdukID');
        $this->home_model->update_produk($Namaproduk,$Hargaproduk,$Keterangan,$ProdukID);
        $this->session->set_flashdata('notifikasi','<div class="alert alert-primary" role="alert">Data berhasil diupdate</div>');
        redirect('home/data_produk');
    }
    function deletedata($IdProduk){
        $this->home_model->hapus_produk($IdProduk);
        $this->session->set_flashdata('notifikasi','<div class="alert alert-primary" role="alert">Data berhasil dihapus</div>');
        redirect('home/data_produk');
    }
}