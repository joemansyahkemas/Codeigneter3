<div class='container'> 
<h2><?= $tema; ?></h2>
<?= $this->session->flashdata('notifikasi'); ?>
<a href="<?= base_url('index.php/home/add_produk') ?>" class='btn btn-primary'>Tambah Data</a>
<table class='table'>
    <tr>
        <td>No</td>
        <td>Produk ID</td>
        <td>Nama Produk</td>
        <td>Harga Produk</td>
        <td>Keterangan Produk</td>
        <td>#</td>
    </tr>
    <?php 
    $no = 1;
    foreach($produk as $hasil){
    ?>
        <tr>
            <td><?= $no++; ?></td>
            <td><?= $hasil->ProdukID; ?></td>
            <td><?= $hasil->NamaProduk; ?></td>
            <td><?= $hasil->HargaProduk; ?></td>
            <td><?= $hasil->KeteranganProduk; ?></td>
            <td><a href="<?= base_url("index.php/homeproses/deletedata/$hasil->ProdukID") ?>" class="btn btn-danger" onclick="return confirm('Apakah anda yakin menghapus data ?')">Hapus</a> | 
            <a href="<?= base_url("index.php/home/edit_produk/$hasil->ProdukID") ?>" class="btn btn-warning">Edit</a>
            </td>
        </tr>
    <?php }?>
</table>
</div>