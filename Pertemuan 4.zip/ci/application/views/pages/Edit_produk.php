<div class="container">
    <h1>Edit Data Produk</h1>
    <form action="<?= base_url('index.php/homeproses/updatedata') ?>" method="POST">
        <div class="form-group">
            <label>Nama produk</label>
            <input type="text" name="NamaProduk" required class="form-control" placeholder="Masukan Nama Produk" value="<?= $produk['NamaProduk'] ?>"/>
            <input type="hidden" name="ProdukID" required class="form-control"  value="<?= $produk['ProdukID'] ?>"/>
        </div>
        <div class="form-group">
            <label>Harga produk</label>
            <input type="number" name="HargaProduk" required class="form-control" placeholder="Masukan Harga Produk" value="<?= $produk['HargaProduk'] ?>"/>
        </div>
        <div class="form-group">
            <label>Keterangan</label>
           <textarea class="form-control" name="Keterangan" required placeholder="Masukan Keterangan Produk"><?= $produk['KeteranganProduk'] ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Update Produk</button>
        <button type="reset" class="btn btn-warning">Kosongkan</button>
        <a href="<?= base_url('index.php/home/data_produk') ?>" class="btn btn-danger">Kembali</a>
    </form>
</div>