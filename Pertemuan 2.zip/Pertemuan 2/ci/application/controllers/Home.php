<?php
class Home extends CI_Controller{
    function index(){
        $this->load->view('template/Header');
        $this->load->view('pages/Halaman_utama');
        $this->load->view('template/Footer');
    }
    function profil(){
        $this->load->view('template/Header');
        $this->load->view('pages/Halaman_profil');
        $this->load->view('template/Footer');
    }
    function kalkulator(){
        $this->load->view('template/Header');
        $this->load->view('pages/Kalkulator');
        $this->load->view('template/Footer');
    }
}