<?php
class Homeproses extends CI_Controller{
    function proseshitung(){
        $angka1 = $this->input->post('angka1');
        $angka2 = $this->input->post('angka2');
        $operator = $this->input->post('operator');
        if($operator == '+'){
            $hasil = $angka1 + $angka2;
            echo $angka1.'+'.$angka2.'='.$hasil;
        }elseif($operator == '-'){
            $hasil = $angka2 - $angka2;
            echo $angka1.'-'.$angka2.'='.$hasil;
        }elseif($operator == '/'){ 
            $hasil = $angka2 / $angka2;
            echo $angka1.'/'.$angka2.'='.$hasil;
        }elseif($operator == '*'){
            $hasil = $angka2 * $angka2;
            echo $angka1.'*'.$angka2.'='.$hasil;
        }else{
            echo "Operator belum didukung oleh sistem";
        }
    }
}