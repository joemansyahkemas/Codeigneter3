<form method="POST" action='<?= site_url('homeproses/proseshitung') ?>'>
Angka 1 
<input type="number" value="" required class='form-control' name="angka1"/>
<br>
Angka 2 
<input type="number" value="" required class='form-control' name="angka2"/>
<br>
<select class='form-control' name="operator">
<option value="">Bebas</option>
<option value="-">Pengurangan</option>
    <option value="/">Pembagian</option>
    <option value="+">Penjumlahan</option>
    <option value="*">Perkalian</option>
</select>
<button type="submit" class='btn btn-primary'>Kirim</button>
</form>